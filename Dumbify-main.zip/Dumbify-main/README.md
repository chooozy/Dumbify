Dumbify dumbs down any concept into an east to understand concept you are passionante about. 
Please enter a claude API key on line 13
